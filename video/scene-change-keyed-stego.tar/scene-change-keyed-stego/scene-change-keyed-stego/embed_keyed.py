#!/usr/bin/env python3
import argparse
import hashlib
import json
import random
import shutil
from pathlib import Path

import cv2

from scene_utils import parse_scene_list, payload_to_bits, save_json, transition_frames


def main():
    parser = argparse.ArgumentParser(description="Embed payload bits into scene-change windows using a secret key.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--payload", default="payload.bin")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--output-dir", default="stego_frames")
    parser.add_argument("--radius", type=int, default=2)
    parser.add_argument("--manifest", default="embed_manifest.json")
    args = parser.parse_args()

    frames_dir = Path(args.frames_dir)
    out_dir = Path(args.output_dir)
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)

    frame_files = sorted(frames_dir.glob("frame_*.png"))
    if not frame_files:
        raise SystemExit("No input frames found")
    for frame_file in frame_files:
        shutil.copy2(frame_file, out_dir / frame_file.name)

    scene_list = parse_scene_list(args.scene_list)
    selected_frames = transition_frames(scene_list, len(frame_files), args.radius)
    payload = Path(args.payload).read_bytes()
    bits = payload_to_bits(payload)
    key = Path(args.key).read_text(encoding="utf-8").strip()
    if not key:
        raise SystemExit("key.txt is empty")

    sample = cv2.imread(str(frame_files[0]))
    height, width = sample.shape[:2]
    positions = []
    for frame_index in selected_frames:
        for pixel_index in range(width * height):
            positions.append((frame_index, pixel_index))

    if len(bits) > len(positions):
        raise SystemExit("Payload does not fit selected scene-change windows")

    seed = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "big")
    rng = random.Random(seed)
    rng.shuffle(positions)
    chosen = positions[: len(bits)]
    by_frame = {}
    for bit, (frame_index, pixel_index) in zip(bits, chosen):
        by_frame.setdefault(frame_index, []).append((pixel_index, bit))

    modified_pixels = 0
    for frame_index, changes in by_frame.items():
        path = out_dir / f"frame_{frame_index:04d}.png"
        image = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if image is None:
            raise SystemExit(f"Could not read output frame {path}")
        for pixel_index, bit in changes:
            y = pixel_index // width
            x = pixel_index % width
            old_value = int(image[y, x, 0])
            new_value = (old_value & 0xFE) | bit
            if new_value != old_value:
                modified_pixels += 1
            image[y, x, 0] = new_value
        cv2.imwrite(str(path), image)

    manifest = {
        "payload_bits": len(bits),
        "payload_bytes": len(payload),
        "key_hash_prefix": hashlib.sha256(key.encode("utf-8")).hexdigest()[:12],
        "scene_frames": scene_list,
        "embedding_frames": selected_frames,
        "frames_used": sorted(by_frame.keys()),
        "modified_pixels": modified_pixels,
    }
    save_json(args.manifest, manifest)

    if len(by_frame) < 3 or modified_pixels == 0:
        raise SystemExit(f"Embedding sanity check failed: {manifest}")

    print(f"Embedded {len(bits)} bits into {len(by_frame)} keyed scene-change frames")
    print(f"Modified pixels: {modified_pixels}")
    print("CHECK5_OK keyed_embedding_done")


if __name__ == "__main__":
    main()
