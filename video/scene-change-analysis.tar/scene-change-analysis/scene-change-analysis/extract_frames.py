#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import cv2


def main():
    parser = argparse.ArgumentParser(description="Extract video frames and metadata.")
    parser.add_argument("--video", default="input.mp4")
    parser.add_argument("--output", default="frames")
    parser.add_argument("--metadata", default="video_info.json")
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.exists():
        raise SystemExit(f"Video file not found: {video_path}")

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    for old_file in out_dir.glob("frame_*.png"):
        old_file.unlink()

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise SystemExit(f"Could not open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = 0

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame_count += 1
        cv2.imwrite(str(out_dir / f"frame_{frame_count:04d}.png"), frame)

    cap.release()

    metadata = {
        "video": str(video_path),
        "fps": round(float(fps), 3),
        "frame_count": frame_count,
        "width": width,
        "height": height,
    }
    with open(args.metadata, "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    if frame_count < 100 or width <= 0 or height <= 0:
        raise SystemExit("Frame extraction failed basic sanity checks")

    print(f"Extracted {frame_count} frames at {fps:.2f} fps from {video_path}")
    print(f"Metadata saved to {args.metadata}")
    print("CHECK1_OK frames_extracted")


if __name__ == "__main__":
    main()
