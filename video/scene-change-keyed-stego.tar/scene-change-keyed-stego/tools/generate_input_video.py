#!/usr/bin/env python3
from pathlib import Path

import cv2
import numpy as np


WIDTH = 320
HEIGHT = 240
FPS = 10


def scene_frame(scene_id, local_index):
    image = np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8)
    palettes = [
        ((40, 70, 210), (255, 245, 220)),
        ((40, 175, 80), (20, 30, 80)),
        ((210, 180, 40), (250, 250, 250)),
        ((170, 45, 145), (255, 230, 50)),
        ((45, 185, 205), (30, 30, 30)),
        ((205, 90, 40), (240, 240, 255)),
    ]
    bg, fg = palettes[scene_id]
    image[:] = bg
    if scene_id % 2 == 0:
        x = 20 + (local_index * 7) % 210
        y = 40 + (scene_id * 18) % 120
        cv2.rectangle(image, (x, y), (x + 65, y + 45), fg, -1)
        cv2.circle(image, (260 - x // 2, 170), 24, tuple(reversed(fg)), -1)
    else:
        center = (50 + (local_index * 9) % 220, 70 + (local_index * 5) % 110)
        cv2.circle(image, center, 38, fg, -1)
        cv2.line(image, (0, 35 + local_index % 120), (WIDTH - 1, 90 + local_index % 120), tuple(reversed(fg)), 5)
    cv2.putText(image, f"SCENE {scene_id + 1}", (88, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4)
    cv2.putText(image, f"SCENE {scene_id + 1}", (88, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, fg, 2)
    return image


def add_scene(frames, scene_id, count):
    for i in range(count):
        frames.append(scene_frame(scene_id, i))


def add_fade(frames, from_scene, to_scene, count):
    for i in range(count):
        alpha = (i + 1) / (count + 1)
        left = scene_frame(from_scene, 20 + i)
        right = scene_frame(to_scene, i)
        frames.append(cv2.addWeighted(left, 1.0 - alpha, right, alpha, 0))


def main():
    output = Path(__file__).resolve().parents[1] / "scene-change-keyed-stego" / "input.mp4"
    output.parent.mkdir(parents=True, exist_ok=True)
    frames = []
    add_scene(frames, 0, 20)
    add_scene(frames, 1, 20)
    add_fade(frames, 1, 2, 8)
    add_scene(frames, 2, 20)
    add_scene(frames, 3, 20)
    add_fade(frames, 3, 4, 8)
    add_scene(frames, 4, 20)
    add_scene(frames, 5, 20)
    writer = cv2.VideoWriter(str(output), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (WIDTH, HEIGHT))
    if not writer.isOpened():
        raise SystemExit("Could not create input video")
    for frame in frames:
        writer.write(frame)
    writer.release()
    print(f"Wrote {len(frames)} frames to input.mp4")


if __name__ == "__main__":
    main()
