#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path

from scene_utils import parse_scene_list


def main():
    parser = argparse.ArgumentParser(description="Create a final evidence report for the authenticated message.")
    parser.add_argument("--message", default="extracted_message.txt")
    parser.add_argument("--auth", default="auth_report.json")
    parser.add_argument("--scenes", default="scene_frames.txt")
    parser.add_argument("--output", default="final_evidence.txt")
    args = parser.parse_args()

    message = Path(args.message).read_bytes()
    auth = json.loads(Path(args.auth).read_text(encoding="utf-8"))
    scenes = parse_scene_list(args.scenes)
    if not auth.get("authenticated"):
        raise SystemExit("Authentication report does not mark the message as authenticated")
    if auth.get("message_sha256") != hashlib.sha256(message).hexdigest():
        raise SystemExit("Message hash does not match authentication report")
    if len(scenes) != 5:
        raise SystemExit(f"Expected 5 scene changes, found {len(scenes)}")

    text = (
        "Blind extraction evidence\n"
        f"authenticated={auth['authenticated']}\n"
        f"message_bytes={len(message)}\n"
        f"message_sha256={auth['message_sha256']}\n"
        f"crc32={auth['crc32']}\n"
        f"hmac_prefix={auth['hmac_prefix']}\n"
        f"scene_frames={','.join(str(item) for item in scenes)}\n"
        "message_preview=\n"
        f"{message.decode('utf-8', errors='replace')}\n"
    )
    Path(args.output).write_text(text, encoding="utf-8")

    print(f"Evidence report written to {args.output}")
    print(f"Scene frames: {scenes}")
    print("CHECK6_OK evidence_report_ready")


if __name__ == "__main__":
    main()
