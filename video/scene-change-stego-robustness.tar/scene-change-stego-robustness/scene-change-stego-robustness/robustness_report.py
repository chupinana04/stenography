#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Summarize LSB attack damage and robust recovery.")
    parser.add_argument("--attack", default="attack_report.json")
    parser.add_argument("--naive", default="naive_report.json")
    parser.add_argument("--robust", default="robust_report.json")
    parser.add_argument("--output", default="final_robustness.txt")
    args = parser.parse_args()

    attack = json.loads(Path(args.attack).read_text(encoding="utf-8"))
    naive = json.loads(Path(args.naive).read_text(encoding="utf-8"))
    robust = json.loads(Path(args.robust).read_text(encoding="utf-8"))

    if naive.get("naive_authenticated"):
        raise SystemExit("Naive extraction should fail after the attack")
    if not robust.get("authenticated"):
        raise SystemExit("Robust extraction did not authenticate")
    if robust.get("corrected_replicas", 0) < attack.get("flipped_lsb_values", 1):
        raise SystemExit("Robust report corrected fewer replicas than expected")

    text = (
        "Scene-change stego robustness evidence\n"
        f"attack={attack['attack']}\n"
        f"flipped_lsb_values={attack['flipped_lsb_values']}\n"
        f"repetition={attack['repetition']}\n"
        f"naive_authenticated={naive['naive_authenticated']}\n"
        f"naive_failure_reason={naive['failure_reason']}\n"
        f"robust_authenticated={robust['authenticated']}\n"
        f"corrected_replicas={robust['corrected_replicas']}\n"
        f"message_sha256={robust['message_sha256']}\n"
        f"crc32={robust['crc32']}\n"
    )
    Path(args.output).write_text(text, encoding="utf-8")
    print(f"Robustness report written to {args.output}")
    print(f"Naive failed; robust corrected {robust['corrected_replicas']} replicas")
    print("CHECK6_OK robustness_report_ready")


if __name__ == "__main__":
    main()
