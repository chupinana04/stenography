#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import cv2

from scene_utils import parse_scene_list, save_json, transition_frames


def main():
    parser = argparse.ArgumentParser(description="Check keyed steganography capacity in scene-change windows.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--message", default="message.txt")
    parser.add_argument("--radius", type=int, default=2)
    parser.add_argument("--output", default="capacity.json")
    args = parser.parse_args()

    scene_list = parse_scene_list(args.scene_list)
    frame_files = sorted(Path(args.frames_dir).glob("frame_*.png"))
    if not frame_files:
        raise SystemExit("No frames found")
    first = cv2.imread(str(frame_files[0]))
    if first is None:
        raise SystemExit("Could not read first frame")
    height, width = first.shape[:2]
    selected = transition_frames(scene_list, len(frame_files), args.radius)

    message_bytes = Path(args.message).read_bytes()
    payload_bits = (4 + 4 + len(message_bytes) + 4) * 8
    capacity_bits = len(selected) * width * height
    data = {
        "scene_frames": scene_list,
        "embedding_radius": args.radius,
        "embedding_frames": selected,
        "embedding_frame_count": len(selected),
        "width": width,
        "height": height,
        "capacity_bits": capacity_bits,
        "required_payload_bits": payload_bits,
        "capacity_ok": capacity_bits >= payload_bits,
    }
    save_json(args.output, data)
    if not data["capacity_ok"] or len(selected) < 20:
        raise SystemExit(f"Insufficient capacity: {data}")

    print(f"Capacity: {capacity_bits} bits; payload requirement: {payload_bits} bits")
    print(f"Embedding frames: {selected}")
    print("CHECK3_OK capacity_sufficient")


if __name__ == "__main__":
    main()
