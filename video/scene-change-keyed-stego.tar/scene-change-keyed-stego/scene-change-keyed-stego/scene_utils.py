#!/usr/bin/env python3
import csv
import json
import zlib
from pathlib import Path

import cv2
import numpy as np


REFERENCE_SCENES = [21, 45, 69, 93, 117]


def frame_files(frames_dir):
    files = sorted(Path(frames_dir).glob("frame_*.png"))
    if not files:
        raise SystemExit(f"No frame_*.png files found in {frames_dir}")
    return files


def frame_number(path):
    return int(Path(path).stem.split("_")[1])


def parse_scene_list(path):
    scenes = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            scenes.append(int(line.split(",")[0].split()[0]))
    return scenes


def write_scene_list(path, scenes):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("# frame_index\n")
        for scene in scenes:
            handle.write(f"{scene}\n")


def hsv_histogram(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [32, 32], [0, 180, 0, 256])
    cv2.normalize(hist, hist, alpha=1.0, norm_type=cv2.NORM_L1)
    return hist


def detect_scene_changes(frames_dir, threshold=0.30, min_gap=8):
    files = frame_files(frames_dir)
    previous_gray = None
    previous_hist = None
    candidates = []
    scores = []
    for index, frame_path in enumerate(files, start=1):
        frame = cv2.imread(str(frame_path))
        if frame is None:
            raise SystemExit(f"Could not read frame: {frame_path}")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hist = hsv_histogram(frame)
        if previous_gray is not None and previous_hist is not None:
            pixel_diff = float(np.mean(cv2.absdiff(previous_gray, gray)) / 255.0)
            hist_diff = float(cv2.compareHist(previous_hist, hist, cv2.HISTCMP_BHATTACHARYYA))
            score = 0.45 * pixel_diff + 0.55 * hist_diff
            scores.append((index, pixel_diff, hist_diff, score))
            if score >= threshold:
                candidates.append((index, score))
        previous_gray = gray
        previous_hist = hist

    clusters = []
    current = []
    for frame_index, score in candidates:
        if not current or frame_index - current[-1][0] <= min_gap:
            current.append((frame_index, score))
        else:
            clusters.append(current)
            current = [(frame_index, score)]
    if current:
        clusters.append(current)

    scenes = []
    for cluster in clusters:
        weighted = sum(frame * score for frame, score in cluster)
        total = sum(score for _, score in cluster)
        scenes.append(int(round(weighted / total)))
    return scenes, candidates, scores


def transition_frames(scene_list, total_frames, radius=2):
    selected = set()
    for scene in scene_list:
        for frame_index in range(scene - radius, scene + radius + 1):
            if 1 <= frame_index <= total_frames:
                selected.add(frame_index)
    return sorted(selected)


def payload_to_bits(payload):
    bits = []
    for byte in payload:
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def build_payload(message_bytes):
    header = b"SCS1" + len(message_bytes).to_bytes(4, "big")
    crc = zlib.crc32(message_bytes).to_bytes(4, "big")
    return header + message_bytes + crc


def psnr(original, stego):
    mse = np.mean((original.astype(np.float32) - stego.astype(np.float32)) ** 2)
    if mse == 0:
        return 99.0
    return float(20 * np.log10(255.0 / np.sqrt(mse)))


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)


def write_score_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["frame_index", "pixel_diff", "hist_diff", "score"])
        for row in rows:
            writer.writerow([row[0], f"{row[1]:.6f}", f"{row[2]:.6f}", f"{row[3]:.6f}"])
