#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from scene_utils import REFERENCE_SCENES, match_scenes, parse_scene_list


def make_preview(frames_dir, scenes, output_dir):
    frames_dir = Path(frames_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    tiles = []
    for scene in scenes:
        frame_path = frames_dir / f"frame_{scene:04d}.png"
        image = cv2.imread(str(frame_path))
        if image is None:
            raise SystemExit(f"Missing frame for preview: {frame_path}")
        cv2.putText(image, f"scene frame {scene}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 4)
        cv2.putText(image, f"scene frame {scene}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)
        cv2.imwrite(str(output_dir / f"scene_{scene:04d}.png"), image)
        tiles.append(cv2.resize(image, (240, 180)))

    if tiles:
        contact_sheet = np.hstack(tiles)
        cv2.imwrite(str(output_dir / "scene_contact_sheet.png"), contact_sheet)


def main():
    parser = argparse.ArgumentParser(description="Validate detected scene changes and create preview images.")
    parser.add_argument("--frames", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--preview-dir", default="scene_preview")
    parser.add_argument("--report", default="scene_report.json")
    args = parser.parse_args()

    scenes = parse_scene_list(args.scene_list)
    matched, total, found_count = match_scenes(scenes, tolerance=4)
    precision = matched / found_count if found_count else 0.0
    recall = matched / total if total else 0.0

    make_preview(args.frames, scenes, args.preview_dir)

    report = {
        "reference_scenes": REFERENCE_SCENES,
        "detected_scenes": scenes,
        "matched": matched,
        "expected": total,
        "found": found_count,
        "precision": round(precision, 3),
        "recall": round(recall, 3),
    }
    with open(args.report, "w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)

    if matched != total or found_count != total:
        raise SystemExit(f"Scene validation failed: {report}")

    print(f"Preview images written to {args.preview_dir}")
    print(f"Validation report written to {args.report}")
    print("CHECK6_OK scene_preview_validated")


if __name__ == "__main__":
    main()
