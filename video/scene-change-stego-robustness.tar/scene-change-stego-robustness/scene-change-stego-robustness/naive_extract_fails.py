#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import cv2

from scene_utils import bits_to_bytes, extract_lsb_bits, first_replica_bits, keyed_positions, parse_auth_payload
from scene_utils import parse_scene_list, robust_payload_bit_count, save_json


def main():
    parser = argparse.ArgumentParser(description="Show that extraction without voting fails after the attack.")
    parser.add_argument("--frames-dir", default="attacked_frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--config", default="robust_config.json")
    parser.add_argument("--report", default="naive_report.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    frame_files = sorted(Path(args.frames_dir).glob("frame_*.png"))
    if not frame_files:
        raise SystemExit("No attacked frames found")
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise SystemExit("Could not read sample frame")
    height, width = sample.shape[:2]

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    repetition = int(config["repetition"])
    raw_bit_count = robust_payload_bit_count(config)
    key = Path(args.key).read_text(encoding="utf-8").strip()
    scenes = parse_scene_list(args.scene_list)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, args.radius)
    raw_bits = extract_lsb_bits(args.frames_dir, positions, raw_bit_count)
    naive_bits = first_replica_bits(raw_bits, repetition)
    naive_payload = bits_to_bytes(naive_bits)

    failed = False
    reason = "unexpected_success"
    try:
        parse_auth_payload(naive_payload, key)
    except ValueError as error:
        failed = True
        reason = str(error)

    save_json(args.report, {
        "naive_authenticated": not failed,
        "failure_reason": reason,
        "payload_bytes_checked": len(naive_payload),
        "repetition_ignored": repetition,
    })
    if not failed:
        raise SystemExit("Naive extraction unexpectedly authenticated the attacked payload")

    print(f"Naive extraction rejected attacked payload: {reason}")
    print("CHECK4_OK naive_extraction_failed")


if __name__ == "__main__":
    main()
