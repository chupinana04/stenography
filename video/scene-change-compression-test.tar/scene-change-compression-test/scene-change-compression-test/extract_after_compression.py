#!/usr/bin/env python3
import argparse
import json
import shutil
from pathlib import Path

import cv2

from scene_utils import bits_to_bytes, extract_lsb_bits, keyed_positions, parse_auth_payload
from scene_utils import parse_scene_list, save_json


def extract_frames(video_path, frames_dir):
    frames_dir = Path(frames_dir)
    if frames_dir.exists():
        shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Could not open compressed video: {video_path}")
    count = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        count += 1
        cv2.imwrite(str(frames_dir / f"frame_{count:04d}.png"), frame)
    cap.release()
    if count < 100:
        raise ValueError(f"Too few compressed frames extracted: {count}")
    return count


def try_recover_payload(frames_dir, scene_list_path, key_path, radius):
    frame_files = sorted(Path(frames_dir).glob("frame_*.png"))
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise ValueError("Could not read compressed sample frame")
    height, width = sample.shape[:2]
    key = Path(key_path).read_text(encoding="utf-8").strip()
    scenes = parse_scene_list(scene_list_path)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, radius)

    header = bits_to_bytes(extract_lsb_bits(frames_dir, positions, 64))
    if header[:4] != b"SCA1":
        raise ValueError(f"Invalid payload magic after compression: {header[:4].hex()}")
    message_len = int.from_bytes(header[4:8], "big")
    if message_len <= 0 or message_len > 4096:
        raise ValueError(f"Unreasonable message length after compression: {message_len}")
    payload_len = 4 + 4 + message_len + 4 + 16
    payload = bits_to_bytes(extract_lsb_bits(frames_dir, positions, payload_len * 8))
    parsed = parse_auth_payload(payload, key)
    return parsed


def main():
    parser = argparse.ArgumentParser(description="Try to extract the LSB payload after lossy compression.")
    parser.add_argument("--video", default="compressed_stego.mp4")
    parser.add_argument("--frames-dir", default="compressed_frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--report", default="after_report.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    try:
        frame_count = extract_frames(args.video, args.frames_dir)
        parsed = try_recover_payload(args.frames_dir, args.scene_list, args.key, args.radius)
        save_json(args.report, {
            "compressed_authenticated": True,
            "frame_count": frame_count,
            "message_bytes": parsed["message_len"],
            "crc32": parsed["crc32"],
            "failure_reason": None,
        })
        raise SystemExit("Compressed video unexpectedly authenticated the LSB payload")
    except ValueError as error:
        save_json(args.report, {
            "compressed_authenticated": False,
            "frame_count": len(list(Path(args.frames_dir).glob("frame_*.png"))),
            "failure_reason": str(error),
        })
        print(f"Compressed video damaged the LSB payload: {error}")
        print("CHECK5_OK compression_damaged_payload")


if __name__ == "__main__":
    main()
