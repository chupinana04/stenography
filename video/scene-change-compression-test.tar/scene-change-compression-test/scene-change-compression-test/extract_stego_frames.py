#!/usr/bin/env python3
import argparse
import json
import shutil
from pathlib import Path

import cv2


def main():
    parser = argparse.ArgumentParser(description="Extract frames and metadata from the stego video.")
    parser.add_argument("--video", default="stego_video.mkv")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--metadata", default="video_info.json")
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.exists():
        raise SystemExit(f"Video not found: {video_path}")

    frames_dir = Path(args.frames_dir)
    if frames_dir.exists():
        shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise SystemExit(f"Could not open video: {video_path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    count = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        count += 1
        cv2.imwrite(str(frames_dir / f"frame_{count:04d}.png"), frame)
    cap.release()

    metadata = {
        "video": str(video_path),
        "fps": round(fps, 3),
        "frame_count": count,
        "width": width,
        "height": height,
    }
    Path(args.metadata).write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    if count < 100 or width <= 0 or height <= 0:
        raise SystemExit("Frame extraction failed sanity checks")

    print(f"Extracted {count} stego frames from {video_path}")
    print(f"Metadata saved to {args.metadata}")
    print("CHECK1_OK extracted_stego_frames")


if __name__ == "__main__":
    main()
