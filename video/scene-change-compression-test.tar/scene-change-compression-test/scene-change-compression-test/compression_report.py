#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Summarize extraction before and after lossy compression.")
    parser.add_argument("--before", default="before_report.json")
    parser.add_argument("--after", default="after_report.json")
    parser.add_argument("--compression", default="compression_info.json")
    parser.add_argument("--output", default="final_compression_report.txt")
    args = parser.parse_args()

    before = json.loads(Path(args.before).read_text(encoding="utf-8"))
    after = json.loads(Path(args.after).read_text(encoding="utf-8"))
    compression = json.loads(Path(args.compression).read_text(encoding="utf-8"))

    if not before.get("authenticated"):
        raise SystemExit("Before-compression extraction was not authenticated")
    if after.get("compressed_authenticated"):
        raise SystemExit("After-compression extraction should fail for this lab")

    text = (
        "Scene-change compression test evidence\n"
        f"before_authenticated={before['authenticated']}\n"
        f"message_bytes={before['message_bytes']}\n"
        f"message_sha256={before['message_sha256']}\n"
        f"crc32={before['crc32']}\n"
        f"codec={compression['codec']}\n"
        f"crf={compression['crf']}\n"
        f"input_bytes={compression['input_bytes']}\n"
        f"output_bytes={compression['output_bytes']}\n"
        f"after_authenticated={after['compressed_authenticated']}\n"
        f"after_failure_reason={after['failure_reason']}\n"
    )
    Path(args.output).write_text(text, encoding="utf-8")
    print(f"Compression report written to {args.output}")
    print("Lossless stego authenticated before compression; lossy video failed after compression")
    print("CHECK6_OK compression_report_ready")


if __name__ == "__main__":
    main()
