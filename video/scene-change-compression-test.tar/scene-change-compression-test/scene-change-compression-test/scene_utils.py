#!/usr/bin/env python3
import csv
import hashlib
import hmac
import json
import random
import zlib
from pathlib import Path

import cv2
import numpy as np


REFERENCE_SCENES = [21, 45, 69, 93, 117]
AUTH_MAGIC = b"SCA1"
AUTH_TAG_BYTES = 16


def frame_files(frames_dir):
    files = sorted(Path(frames_dir).glob("frame_*.png"))
    if not files:
        raise SystemExit(f"No frame_*.png files found in {frames_dir}")
    return files


def frame_number(path):
    return int(Path(path).stem.split("_")[1])


def parse_scene_list(path):
    scenes = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            scenes.append(int(line.split(",")[0].split()[0]))
    return scenes


def write_scene_list(path, scenes):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("# frame_index\n")
        for scene in scenes:
            handle.write(f"{scene}\n")


def hsv_histogram(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [32, 32], [0, 180, 0, 256])
    cv2.normalize(hist, hist, alpha=1.0, norm_type=cv2.NORM_L1)
    return hist


def detect_scene_changes(frames_dir, threshold=0.30, min_gap=8):
    files = frame_files(frames_dir)
    previous_gray = None
    previous_hist = None
    candidates = []
    scores = []
    for index, frame_path in enumerate(files, start=1):
        frame = cv2.imread(str(frame_path))
        if frame is None:
            raise SystemExit(f"Could not read frame: {frame_path}")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hist = hsv_histogram(frame)
        if previous_gray is not None and previous_hist is not None:
            pixel_diff = float(np.mean(cv2.absdiff(previous_gray, gray)) / 255.0)
            hist_diff = float(cv2.compareHist(previous_hist, hist, cv2.HISTCMP_BHATTACHARYYA))
            score = 0.45 * pixel_diff + 0.55 * hist_diff
            scores.append((index, pixel_diff, hist_diff, score))
            if score >= threshold:
                candidates.append((index, score))
        previous_gray = gray
        previous_hist = hist

    clusters = []
    current = []
    for frame_index, score in candidates:
        if not current or frame_index - current[-1][0] <= min_gap:
            current.append((frame_index, score))
        else:
            clusters.append(current)
            current = [(frame_index, score)]
    if current:
        clusters.append(current)

    scenes = []
    for cluster in clusters:
        weighted = sum(frame * score for frame, score in cluster)
        total = sum(score for _, score in cluster)
        scenes.append(int(round(weighted / total)))
    return scenes, candidates, scores


def transition_frames(scene_list, total_frames, radius=2):
    selected = set()
    for scene in scene_list:
        for frame_index in range(scene - radius, scene + radius + 1):
            if 1 <= frame_index <= total_frames:
                selected.add(frame_index)
    return sorted(selected)


def payload_to_bits(payload):
    bits = []
    for byte in payload:
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def bits_to_bytes(bits):
    if len(bits) % 8 != 0:
        raise ValueError("Bit count must be divisible by 8")
    data = bytearray()
    for offset in range(0, len(bits), 8):
        value = 0
        for bit in bits[offset:offset + 8]:
            value = (value << 1) | int(bit)
        data.append(value)
    return bytes(data)


def build_payload(message_bytes):
    header = b"SCS1" + len(message_bytes).to_bytes(4, "big")
    crc = zlib.crc32(message_bytes).to_bytes(4, "big")
    return header + message_bytes + crc


def build_auth_payload(message_bytes, key):
    header = AUTH_MAGIC + len(message_bytes).to_bytes(4, "big")
    crc = zlib.crc32(message_bytes).to_bytes(4, "big")
    body = header + message_bytes + crc
    tag = hmac.new(key.encode("utf-8"), body, hashlib.sha256).digest()[:AUTH_TAG_BYTES]
    return body + tag


def parse_auth_payload(payload, key):
    minimum = 4 + 4 + 4 + AUTH_TAG_BYTES
    if len(payload) < minimum:
        raise ValueError("Payload is too short")
    if payload[:4] != AUTH_MAGIC:
        raise ValueError("Invalid payload magic")
    message_len = int.from_bytes(payload[4:8], "big")
    expected_len = 4 + 4 + message_len + 4 + AUTH_TAG_BYTES
    if len(payload) != expected_len:
        raise ValueError(f"Payload length mismatch: expected {expected_len}, got {len(payload)}")
    message = payload[8:8 + message_len]
    crc_offset = 8 + message_len
    stored_crc = int.from_bytes(payload[crc_offset:crc_offset + 4], "big")
    computed_crc = zlib.crc32(message) & 0xFFFFFFFF
    if stored_crc != computed_crc:
        raise ValueError(f"CRC mismatch: stored {stored_crc:08x}, computed {computed_crc:08x}")
    body = payload[:crc_offset + 4]
    stored_tag = payload[crc_offset + 4:]
    computed_tag = hmac.new(key.encode("utf-8"), body, hashlib.sha256).digest()[:AUTH_TAG_BYTES]
    if not hmac.compare_digest(stored_tag, computed_tag):
        raise ValueError("HMAC authentication failed")
    return {
        "message": message,
        "message_len": message_len,
        "crc32": f"{computed_crc:08x}",
        "hmac_prefix": stored_tag.hex(),
    }


def keyed_positions(key, scene_list, total_frames, width, height, radius=2):
    selected_frames = transition_frames(scene_list, total_frames, radius)
    positions = []
    for frame_index in selected_frames:
        for pixel_index in range(width * height):
            positions.append((frame_index, pixel_index))
    seed = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "big")
    rng = random.Random(seed)
    rng.shuffle(positions)
    return positions


def extract_lsb_bits(frames_dir, positions, bit_count):
    bits = []
    cache = {}
    frames_dir = Path(frames_dir)
    for frame_index, pixel_index in positions[:bit_count]:
        image = cache.get(frame_index)
        if image is None:
            path = frames_dir / f"frame_{frame_index:04d}.png"
            image = cv2.imread(str(path), cv2.IMREAD_COLOR)
            if image is None:
                raise ValueError(f"Could not read frame {path}")
            cache[frame_index] = image
        height, width = image.shape[:2]
        y = pixel_index // width
        x = pixel_index % width
        bits.append(int(image[y, x, 0]) & 1)
    return bits


def psnr(original, stego):
    mse = np.mean((original.astype(np.float32) - stego.astype(np.float32)) ** 2)
    if mse == 0:
        return 99.0
    return float(20 * np.log10(255.0 / np.sqrt(mse)))


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)


def write_score_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["frame_index", "pixel_diff", "hist_diff", "score"])
        for row in rows:
            writer.writerow([row[0], f"{row[1]:.6f}", f"{row[2]:.6f}", f"{row[3]:.6f}"])
