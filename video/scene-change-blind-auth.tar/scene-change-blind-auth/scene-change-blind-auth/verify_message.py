#!/usr/bin/env python3
import argparse
import hashlib
from pathlib import Path

from scene_utils import parse_auth_payload, save_json


def main():
    parser = argparse.ArgumentParser(description="Verify the recovered message CRC32 and HMAC tag.")
    parser.add_argument("--payload", default="recovered_payload.bin")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--message", default="extracted_message.txt")
    parser.add_argument("--report", default="auth_report.json")
    args = parser.parse_args()

    payload = Path(args.payload).read_bytes()
    key = Path(args.key).read_text(encoding="utf-8").strip()
    try:
        parsed = parse_auth_payload(payload, key)
    except ValueError as error:
        raise SystemExit(str(error))

    Path(args.message).write_bytes(parsed["message"])
    report = {
        "authenticated": True,
        "message_bytes": parsed["message_len"],
        "crc32": parsed["crc32"],
        "hmac_prefix": parsed["hmac_prefix"],
        "message_sha256": hashlib.sha256(parsed["message"]).hexdigest(),
    }
    save_json(args.report, report)

    print(f"Authenticated message length: {parsed['message_len']} bytes")
    print(f"CRC32: {parsed['crc32']}")
    print(f"HMAC prefix: {parsed['hmac_prefix']}")
    print("CHECK4_OK message_authenticated")


if __name__ == "__main__":
    main()
