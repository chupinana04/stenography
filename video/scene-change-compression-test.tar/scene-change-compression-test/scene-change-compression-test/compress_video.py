#!/usr/bin/env python3
import argparse
import subprocess
from pathlib import Path

from scene_utils import save_json


def main():
    parser = argparse.ArgumentParser(description="Compress a stego video with lossy H.264 settings.")
    parser.add_argument("--input", default="stego_video.mkv")
    parser.add_argument("--output", default="compressed_stego.mp4")
    parser.add_argument("--crf", type=int, default=32)
    parser.add_argument("--report", default="compression_info.json")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    if not input_path.exists():
        raise SystemExit(f"Input video not found: {input_path}")
    if output_path.exists():
        output_path.unlink()

    cmd = [
        "ffmpeg", "-y", "-i", str(input_path),
        "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", str(args.crf),
        "-pix_fmt", "yuv420p", str(output_path),
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0 or not output_path.exists() or output_path.stat().st_size == 0:
        raise SystemExit(proc.stderr[-1200:])

    report = {
        "input": str(input_path),
        "output": str(output_path),
        "codec": "libx264",
        "crf": args.crf,
        "input_bytes": input_path.stat().st_size,
        "output_bytes": output_path.stat().st_size,
    }
    save_json(args.report, report)
    print(f"Compressed {input_path} to {output_path} with H.264 CRF {args.crf}")
    print(f"Size: {report['input_bytes']} -> {report['output_bytes']} bytes")
    print("CHECK4_OK video_compressed")


if __name__ == "__main__":
    main()
