#!/usr/bin/env python3
import argparse
import hashlib
from pathlib import Path

import cv2

from scene_utils import bits_to_bytes, extract_lsb_bits, keyed_positions, parse_auth_payload
from scene_utils import parse_scene_list, save_json


def recover_payload(frames_dir, scene_list_path, key_path, radius):
    frame_files = sorted(Path(frames_dir).glob("frame_*.png"))
    if not frame_files:
        raise ValueError("No frame_*.png files found")
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise ValueError(f"Could not read sample frame {frame_files[0]}")
    height, width = sample.shape[:2]

    key = Path(key_path).read_text(encoding="utf-8").strip()
    scenes = parse_scene_list(scene_list_path)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, radius)

    header = bits_to_bytes(extract_lsb_bits(frames_dir, positions, 64))
    if header[:4] != b"SCA1":
        raise ValueError("Invalid payload magic before compression")
    message_len = int.from_bytes(header[4:8], "big")
    if message_len <= 0 or message_len > 4096:
        raise ValueError(f"Unreasonable message length: {message_len}")
    payload_len = 4 + 4 + message_len + 4 + 16
    payload = bits_to_bytes(extract_lsb_bits(frames_dir, positions, payload_len * 8))
    return payload, key, scenes


def main():
    parser = argparse.ArgumentParser(description="Recover and authenticate the payload before compression.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--payload", default="payload_before.bin")
    parser.add_argument("--message", default="message_before.txt")
    parser.add_argument("--report", default="before_report.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    try:
        payload, key, scenes = recover_payload(args.frames_dir, args.scene_list, args.key, args.radius)
        parsed = parse_auth_payload(payload, key)
    except ValueError as error:
        raise SystemExit(str(error))

    Path(args.payload).write_bytes(payload)
    Path(args.message).write_bytes(parsed["message"])
    report = {
        "authenticated": True,
        "payload_bytes": len(payload),
        "message_bytes": parsed["message_len"],
        "crc32": parsed["crc32"],
        "hmac_prefix": parsed["hmac_prefix"],
        "message_sha256": hashlib.sha256(parsed["message"]).hexdigest(),
        "scene_frames": scenes,
    }
    save_json(args.report, report)

    print(f"Recovered authenticated payload before compression: {len(payload)} bytes")
    print(f"Message bytes: {parsed['message_len']}; CRC32: {parsed['crc32']}")
    print("CHECK3_OK extracted_before_compression")


if __name__ == "__main__":
    main()
