#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

import cv2

from scene_utils import bits_to_bytes, extract_lsb_bits, keyed_positions, parse_scene_list, save_json


def recover_payload(frames_dir, scene_list_path, key_path, radius):
    frame_files = sorted(Path(frames_dir).glob("frame_*.png"))
    if not frame_files:
        raise ValueError("No frame_*.png files found")
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise ValueError(f"Could not read sample frame {frame_files[0]}")
    height, width = sample.shape[:2]

    key = Path(key_path).read_text(encoding="utf-8").strip()
    if not key:
        raise ValueError("Key file is empty")
    scenes = parse_scene_list(scene_list_path)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, radius)

    header = bits_to_bytes(extract_lsb_bits(frames_dir, positions, 64))
    if header[:4] != b"SCA1":
        raise ValueError("Could not recover a valid SCA1 header with this key")
    message_len = int.from_bytes(header[4:8], "big")
    if message_len <= 0 or message_len > 4096:
        raise ValueError(f"Recovered message length is unreasonable: {message_len}")
    payload_len = 4 + 4 + message_len + 4 + 16
    payload = bits_to_bytes(extract_lsb_bits(frames_dir, positions, payload_len * 8))
    return payload, scenes, len(positions), message_len


def main():
    parser = argparse.ArgumentParser(description="Blindly extract a keyed payload from scene-change windows.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--payload", default="recovered_payload.bin")
    parser.add_argument("--message", default="extracted_message.txt")
    parser.add_argument("--auth", default="candidate_auth.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    try:
        payload, scenes, position_count, message_len = recover_payload(
            args.frames_dir, args.scene_list, args.key, args.radius
        )
    except ValueError as error:
        raise SystemExit(str(error))

    Path(args.payload).write_bytes(payload)
    message = payload[8:8 + message_len]
    Path(args.message).write_bytes(message)
    save_json(args.auth, {
        "candidate_payload_bytes": len(payload),
        "candidate_message_bytes": message_len,
        "scene_frames": scenes,
        "available_keyed_positions": position_count,
    })

    print(f"Recovered candidate payload: {len(payload)} bytes")
    print(f"Recovered candidate message: {message_len} bytes")
    print("CHECK3_OK blind_payload_extracted")


if __name__ == "__main__":
    main()
