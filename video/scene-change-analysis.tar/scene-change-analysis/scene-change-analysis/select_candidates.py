#!/usr/bin/env python3
import argparse

from scene_utils import match_scenes, read_metric_csv, write_rows


def main():
    parser = argparse.ArgumentParser(description="Combine pixel and histogram metrics to select scene-change candidates.")
    parser.add_argument("--frame-diff", default="frame_diff.csv")
    parser.add_argument("--hist-diff", default="hist_diff.csv")
    parser.add_argument("--output", default="scene_candidates.txt")
    parser.add_argument("--threshold", type=float, default=0.30)
    parser.add_argument("--pixel-weight", type=float, default=0.45)
    parser.add_argument("--hist-weight", type=float, default=0.55)
    args = parser.parse_args()

    pixel_rows = {row["frame_index"]: row for row in read_metric_csv(args.frame_diff)}
    hist_rows = {row["frame_index"]: row for row in read_metric_csv(args.hist_diff)}
    rows = []
    candidates = []

    for frame_index in sorted(set(pixel_rows) & set(hist_rows)):
        pixel = pixel_rows[frame_index]["pixel_diff"]
        hist = hist_rows[frame_index]["hist_diff"]
        score = args.pixel_weight * pixel + args.hist_weight * hist
        row = {
            "frame_index": frame_index,
            "pixel_diff": f"{pixel:.6f}",
            "hist_diff": f"{hist:.6f}",
            "score": f"{score:.6f}",
        }
        rows.append(row)
        if score >= args.threshold:
            candidates.append(row)

    write_rows("scene_scores.csv", ["frame_index", "pixel_diff", "hist_diff", "score"], rows)
    write_rows(args.output, ["frame_index", "pixel_diff", "hist_diff", "score"], candidates)

    found = [int(row["frame_index"]) for row in candidates]
    matched, total, found_count = match_scenes(found, tolerance=5)
    if matched < total or found_count < total:
        raise SystemExit(
            f"Candidate selection is too weak: matched={matched}/{total}, candidates={found_count}. "
            "Try a lower threshold."
        )
    if found_count > 25:
        raise SystemExit(
            f"Too many candidates ({found_count}). Try a higher threshold or inspect scene_scores.csv."
        )

    print(f"Saved {found_count} candidate rows to {args.output}")
    print("Combined score saved to scene_scores.csv")
    print("CHECK4_OK scene_candidates")


if __name__ == "__main__":
    main()
