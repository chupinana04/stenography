#!/usr/bin/env python3
import argparse
from pathlib import Path

import cv2
import numpy as np

from scene_utils import frame_files, write_rows


def main():
    parser = argparse.ArgumentParser(description="Compute mean absolute pixel difference between adjacent frames.")
    parser.add_argument("--frames", default="frames")
    parser.add_argument("--output", default="frame_diff.csv")
    args = parser.parse_args()

    files = frame_files(args.frames)
    prev = None
    rows = []
    max_diff = 0.0
    max_frame = 0

    for index, frame_path in enumerate(files, start=1):
        frame = cv2.imread(str(frame_path))
        if frame is None:
            raise SystemExit(f"Could not read {frame_path}")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if prev is not None:
            diff = float(np.mean(cv2.absdiff(prev, gray)) / 255.0)
            rows.append({
                "frame_index": index,
                "previous_frame": files[index - 2].name,
                "current_frame": frame_path.name,
                "pixel_diff": f"{diff:.6f}",
            })
            if diff > max_diff:
                max_diff = diff
                max_frame = index
        prev = gray

    write_rows(args.output, ["frame_index", "previous_frame", "current_frame", "pixel_diff"], rows)

    if len(rows) < 100 or max_diff < 0.20:
        raise SystemExit("Pixel difference report did not pass sanity checks")

    print(f"Saved {len(rows)} adjacent-frame pixel differences to {args.output}")
    print(f"Maximum pixel difference {max_diff:.4f} at frame {max_frame}")
    print("CHECK2_OK frame_diff_report")


if __name__ == "__main__":
    main()
