#!/usr/bin/env python3
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

import cv2
import numpy as np


LAB_ROOT = Path(__file__).resolve().parents[1]
HOME_DIR = LAB_ROOT / "scene-change-compression-test"
sys.path.insert(0, str(HOME_DIR))

from scene_utils import build_auth_payload, keyed_positions, payload_to_bits  # noqa: E402


WIDTH = 320
HEIGHT = 240
FPS = 10.0
KEY = "scene-change-compression-key-2026"
MESSAGE = (
    "Thong diep LSB nay tach duoc tu video lossless, nhung se bi hong sau khi "
    "video duoc nen lai bang H.264 voi tham so mat du lieu."
).encode("utf-8")


def scene_frame(scene_id, local_index):
    image = np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8)
    palettes = [
        ((40, 70, 210), (255, 245, 220)),
        ((40, 175, 80), (20, 30, 80)),
        ((210, 180, 40), (250, 250, 250)),
        ((170, 45, 145), (255, 230, 50)),
        ((45, 185, 205), (30, 30, 30)),
        ((205, 90, 40), (240, 240, 255)),
    ]
    bg, fg = palettes[scene_id]
    image[:] = bg
    if scene_id % 2 == 0:
        x = 20 + (local_index * 7) % 210
        y = 40 + (scene_id * 18) % 120
        cv2.rectangle(image, (x, y), (x + 65, y + 45), fg, -1)
        cv2.circle(image, (260 - x // 2, 170), 24, tuple(reversed(fg)), -1)
    else:
        center = (50 + (local_index * 9) % 220, 70 + (local_index * 5) % 110)
        cv2.circle(image, center, 38, fg, -1)
        cv2.line(image, (0, 35 + local_index % 120), (WIDTH - 1, 90 + local_index % 120), tuple(reversed(fg)), 5)
    cv2.putText(image, f"SCENE {scene_id + 1}", (88, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4)
    cv2.putText(image, f"SCENE {scene_id + 1}", (88, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, fg, 2)
    return image


def add_scene(frames, scene_id, count):
    for i in range(count):
        frames.append(scene_frame(scene_id, i))


def add_fade(frames, from_scene, to_scene, count):
    for i in range(count):
        alpha = (i + 1) / (count + 1)
        left = scene_frame(from_scene, 20 + i)
        right = scene_frame(to_scene, i)
        frames.append(cv2.addWeighted(left, 1.0 - alpha, right, alpha, 0))


def make_frames():
    frames = []
    add_scene(frames, 0, 20)
    add_scene(frames, 1, 20)
    add_fade(frames, 1, 2, 8)
    add_scene(frames, 2, 20)
    add_scene(frames, 3, 20)
    add_fade(frames, 3, 4, 8)
    add_scene(frames, 4, 20)
    add_scene(frames, 5, 20)
    return frames


def detect_scene_changes_from_frames(frames):
    previous_gray = None
    previous_hist = None
    candidates = []
    for index, frame in enumerate(frames, start=1):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [32, 32], [0, 180, 0, 256])
        cv2.normalize(hist, hist, alpha=1.0, norm_type=cv2.NORM_L1)
        if previous_gray is not None and previous_hist is not None:
            pixel_diff = float(np.mean(cv2.absdiff(previous_gray, gray)) / 255.0)
            hist_diff = float(cv2.compareHist(previous_hist, hist, cv2.HISTCMP_BHATTACHARYYA))
            score = 0.45 * pixel_diff + 0.55 * hist_diff
            if score >= 0.30:
                candidates.append((index, score))
        previous_gray = gray
        previous_hist = hist
    clusters = []
    current = []
    for frame_index, score in candidates:
        if not current or frame_index - current[-1][0] <= 8:
            current.append((frame_index, score))
        else:
            clusters.append(current)
            current = [(frame_index, score)]
    if current:
        clusters.append(current)
    scenes = []
    for cluster in clusters:
        weighted = sum(frame * score for frame, score in cluster)
        total = sum(score for _, score in cluster)
        scenes.append(int(round(weighted / total)))
    return scenes


def embed_payload(frames, payload):
    scenes = detect_scene_changes_from_frames(frames)
    positions = keyed_positions(KEY, scenes, len(frames), WIDTH, HEIGHT, radius=2)
    bits = payload_to_bits(payload)
    if len(bits) > len(positions):
        raise SystemExit("Payload does not fit scene-change windows")
    stego = [frame.copy() for frame in frames]
    for bit, (frame_index, pixel_index) in zip(bits, positions):
        image = stego[frame_index - 1]
        y = pixel_index // WIDTH
        x = pixel_index % WIDTH
        image[y, x, 0] = (int(image[y, x, 0]) & 0xFE) | bit
    return stego, scenes


def write_video(path, frames):
    temp_path = Path(os.environ.get("TEMP", "/tmp")) / "scene-change-compression-stego.mkv"
    if temp_path.exists():
        temp_path.unlink()
    writer = cv2.VideoWriter(str(temp_path), cv2.VideoWriter_fourcc(*"FFV1"), FPS, (WIDTH, HEIGHT))
    if not writer.isOpened():
        raise SystemExit("Could not create FFV1 stego video")
    for frame in frames:
        writer.write(frame)
    writer.release()
    if path.exists():
        path.unlink()
    shutil.copy2(temp_path, path)


def main():
    HOME_DIR.mkdir(parents=True, exist_ok=True)
    payload = build_auth_payload(MESSAGE, KEY)
    frames = make_frames()
    stego, scenes = embed_payload(frames, payload)
    write_video(HOME_DIR / "stego_video.mkv", stego)
    (HOME_DIR / "key.txt").write_text(KEY + "\n", encoding="utf-8")
    (HOME_DIR / "asset_info.json").write_text(json.dumps({
        "scene_frames": scenes,
        "payload_bytes": len(payload),
        "message_sha256": hashlib.sha256(MESSAGE).hexdigest(),
    }, indent=2), encoding="utf-8")
    print(f"Wrote stego_video.mkv with {len(stego)} frames")
    print(f"Scene changes: {scenes}")
    print(f"Payload bytes: {len(payload)}")


if __name__ == "__main__":
    main()
