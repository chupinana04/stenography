#!/usr/bin/env python3
import argparse
import json
import shutil
from pathlib import Path

import cv2

from scene_utils import keyed_positions, parse_scene_list, robust_payload_bit_count, save_json


def main():
    parser = argparse.ArgumentParser(description="Apply a deterministic LSB attack to repeated payload bits.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--config", default="robust_config.json")
    parser.add_argument("--output-dir", default="attacked_frames")
    parser.add_argument("--report", default="attack_report.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    frames_dir = Path(args.frames_dir)
    output_dir = Path(args.output_dir)
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)
    for frame_file in sorted(frames_dir.glob("frame_*.png")):
        shutil.copy2(frame_file, output_dir / frame_file.name)

    frame_files = sorted(output_dir.glob("frame_*.png"))
    if not frame_files:
        raise SystemExit("No frames found to attack")
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise SystemExit("Could not read sample frame")
    height, width = sample.shape[:2]

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    repetition = int(config["repetition"])
    raw_bit_count = robust_payload_bit_count(config)
    key = Path(args.key).read_text(encoding="utf-8").strip()
    scenes = parse_scene_list(args.scene_list)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, args.radius)
    if raw_bit_count > len(positions):
        raise SystemExit("Configured robust payload is larger than keyed position list")

    attacked_by_frame = {}
    groups = raw_bit_count // repetition
    for group_index in range(groups):
        replica_index = (group_index * 3 + 1) % repetition
        position = positions[group_index * repetition + replica_index]
        attacked_by_frame.setdefault(position[0], []).append(position[1])

    flipped = 0
    for frame_index, pixel_indexes in attacked_by_frame.items():
        path = output_dir / f"frame_{frame_index:04d}.png"
        image = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if image is None:
            raise SystemExit(f"Could not read attacked frame {path}")
        for pixel_index in pixel_indexes:
            y = pixel_index // width
            x = pixel_index % width
            image[y, x, 0] = int(image[y, x, 0]) ^ 1
            flipped += 1
        cv2.imwrite(str(path), image)

    report = {
        "attack": "one_lsb_flip_per_repetition_group",
        "payload_groups": groups,
        "repetition": repetition,
        "flipped_lsb_values": flipped,
        "attacked_frames": sorted(attacked_by_frame),
    }
    save_json(args.report, report)

    if flipped != groups or len(attacked_by_frame) < 3:
        raise SystemExit(f"Attack sanity check failed: {report}")
    print(f"Applied LSB attack to {flipped} repeated payload groups")
    print(f"Attacked frame count: {len(attacked_by_frame)}")
    print("CHECK3_OK lsb_attack_applied")


if __name__ == "__main__":
    main()
