#!/usr/bin/env python3
import argparse
import json
import subprocess
from pathlib import Path

import cv2
import numpy as np

from scene_utils import psnr


def main():
    parser = argparse.ArgumentParser(description="Rebuild a lossless video from stego frames and report quality.")
    parser.add_argument("--frames-dir", default="stego_frames")
    parser.add_argument("--original-frames", default="frames")
    parser.add_argument("--metadata", default="video_info.json")
    parser.add_argument("--audio", default="audio.wav")
    parser.add_argument("--output", default="stego_video.mkv")
    parser.add_argument("--quality-report", default="quality_report.txt")
    args = parser.parse_args()

    metadata = json.loads(Path(args.metadata).read_text(encoding="utf-8"))
    fps = str(metadata.get("fps", 10.0))
    output = Path(args.output)
    if output.exists():
        output.unlink()

    temp_video = output
    cmd = [
        "ffmpeg", "-y", "-framerate", fps, "-i", f"{args.frames_dir}/frame_%04d.png",
        "-c:v", "ffv1", "-level", "3", str(temp_video),
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0 or not output.exists() or output.stat().st_size == 0:
        raise SystemExit(proc.stderr[-1000:])

    original_files = sorted(Path(args.original_frames).glob("frame_*.png"))
    stego_files = sorted(Path(args.frames_dir).glob("frame_*.png"))
    if len(original_files) != len(stego_files):
        raise SystemExit("Original and stego frame counts differ")
    values = []
    changed_frames = 0
    for orig_path, stego_path in zip(original_files, stego_files):
        orig = cv2.imread(str(orig_path))
        stego = cv2.imread(str(stego_path))
        if orig is None or stego is None:
            raise SystemExit("Could not read frames during PSNR calculation")
        frame_psnr = psnr(orig, stego)
        values.append(frame_psnr)
        if not np.array_equal(orig, stego):
            changed_frames += 1
    average_psnr = sum(values) / len(values)

    report = (
        f"output={output}\n"
        f"frame_count={len(stego_files)}\n"
        f"changed_frames={changed_frames}\n"
        f"average_psnr={average_psnr:.2f}\n"
        f"codec=ffv1\n"
    )
    Path(args.quality_report).write_text(report, encoding="utf-8")

    if changed_frames == 0 or average_psnr < 55.0:
        raise SystemExit(f"Quality check failed: changed_frames={changed_frames}, psnr={average_psnr:.2f}")

    print(report.strip())
    print("CHECK6_OK lossless_video_ready")


if __name__ == "__main__":
    main()
