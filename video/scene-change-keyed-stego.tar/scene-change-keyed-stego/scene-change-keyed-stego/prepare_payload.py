#!/usr/bin/env python3
import argparse
import zlib
from pathlib import Path

from scene_utils import build_payload


def main():
    parser = argparse.ArgumentParser(description="Build message payload with length header and CRC32.")
    parser.add_argument("--message", default="message.txt")
    parser.add_argument("--output", default="payload.bin")
    args = parser.parse_args()

    message = Path(args.message).read_bytes()
    payload = build_payload(message)
    Path(args.output).write_bytes(payload)
    crc = zlib.crc32(message) & 0xFFFFFFFF

    if not payload.startswith(b"SCS1") or len(payload) <= len(message):
        raise SystemExit("Payload format check failed")

    print(f"Payload saved to {args.output}")
    print(f"Message length: {len(message)} bytes; CRC32: {crc:08x}")
    print("CHECK4_OK payload_ready")


if __name__ == "__main__":
    main()
