#!/usr/bin/env python3
import argparse
import json
import shutil
import subprocess
from pathlib import Path

import cv2


def main():
    parser = argparse.ArgumentParser(description="Extract frames, optional audio, and video metadata.")
    parser.add_argument("--video", default="input.mp4")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--audio", default="audio.wav")
    parser.add_argument("--metadata", default="video_info.json")
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.exists():
        raise SystemExit(f"Video not found: {video_path}")

    frames_dir = Path(args.frames_dir)
    if frames_dir.exists():
        shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise SystemExit(f"Could not open video: {video_path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    count = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        count += 1
        cv2.imwrite(str(frames_dir / f"frame_{count:04d}.png"), frame)
    cap.release()

    audio_present = False
    audio_path = Path(args.audio)
    if audio_path.exists():
        audio_path.unlink()
    cmd = ["ffmpeg", "-y", "-i", str(video_path), "-vn", "-acodec", "pcm_s16le", str(audio_path)]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if proc.returncode == 0 and audio_path.exists() and audio_path.stat().st_size > 44:
            audio_present = True
        else:
            audio_path.write_bytes(b"")
    except FileNotFoundError:
        audio_path.write_bytes(b"")

    metadata = {
        "video": str(video_path),
        "fps": round(fps, 3),
        "frame_count": count,
        "width": width,
        "height": height,
        "audio_present": audio_present,
    }
    with open(args.metadata, "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    if count < 100 or width <= 0 or height <= 0:
        raise SystemExit("Frame extraction failed sanity checks")

    print(f"Extracted {count} frames from {video_path}")
    print(f"Metadata saved to {args.metadata}; audio_present={audio_present}")
    print("CHECK1_OK extracted_frames_audio")


if __name__ == "__main__":
    main()
