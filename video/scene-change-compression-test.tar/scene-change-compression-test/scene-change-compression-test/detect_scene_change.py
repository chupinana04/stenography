#!/usr/bin/env python3
import argparse

from scene_utils import detect_scene_changes, write_scene_list, write_score_csv


def main():
    parser = argparse.ArgumentParser(description="Detect scene-change frames from extracted frames.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--threshold", type=float, default=0.30)
    parser.add_argument("--min-gap", type=int, default=8)
    parser.add_argument("--output", default="scene_frames.txt")
    parser.add_argument("--scores", default="scene_scores.csv")
    args = parser.parse_args()

    scenes, candidates, scores = detect_scene_changes(args.frames_dir, args.threshold, args.min_gap)
    write_scene_list(args.output, scenes)
    write_score_csv(args.scores, scores)

    if len(scenes) != 5:
        raise SystemExit(f"Expected 5 scene changes, found {len(scenes)}. Try threshold 0.30.")

    print(f"Detected scene changes: {scenes}")
    print(f"Candidate count: {len(candidates)}")
    print("CHECK2_OK detected_scene_changes")


if __name__ == "__main__":
    main()
