#!/usr/bin/env python3
import argparse

import cv2

from scene_utils import frame_files, write_rows


def hsv_histogram(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [32, 32], [0, 180, 0, 256])
    cv2.normalize(hist, hist, alpha=1.0, norm_type=cv2.NORM_L1)
    return hist


def main():
    parser = argparse.ArgumentParser(description="Compute HSV histogram distance between adjacent frames.")
    parser.add_argument("--frames", default="frames")
    parser.add_argument("--output", default="hist_diff.csv")
    args = parser.parse_args()

    files = frame_files(args.frames)
    prev_hist = None
    rows = []
    max_diff = 0.0
    max_frame = 0

    for index, frame_path in enumerate(files, start=1):
        frame = cv2.imread(str(frame_path))
        if frame is None:
            raise SystemExit(f"Could not read {frame_path}")
        hist = hsv_histogram(frame)
        if prev_hist is not None:
            diff = float(cv2.compareHist(prev_hist, hist, cv2.HISTCMP_BHATTACHARYYA))
            rows.append({
                "frame_index": index,
                "previous_frame": files[index - 2].name,
                "current_frame": frame_path.name,
                "hist_diff": f"{diff:.6f}",
            })
            if diff > max_diff:
                max_diff = diff
                max_frame = index
        prev_hist = hist

    write_rows(args.output, ["frame_index", "previous_frame", "current_frame", "hist_diff"], rows)

    if len(rows) < 100 or max_diff < 0.25:
        raise SystemExit("Histogram difference report did not pass sanity checks")

    print(f"Saved {len(rows)} adjacent-frame histogram differences to {args.output}")
    print(f"Maximum histogram difference {max_diff:.4f} at frame {max_frame}")
    print("CHECK3_OK histogram_report")


if __name__ == "__main__":
    main()
