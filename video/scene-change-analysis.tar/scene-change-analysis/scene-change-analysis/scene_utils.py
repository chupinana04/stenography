#!/usr/bin/env python3
import csv
from pathlib import Path


REFERENCE_SCENES = [21, 45, 69, 93, 117]


def frame_files(frames_dir):
    path = Path(frames_dir)
    files = sorted(path.glob("frame_*.png"))
    if not files:
        raise SystemExit(f"No frame_*.png files found in {path}")
    return files


def read_metric_csv(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            row["frame_index"] = int(row["frame_index"])
            for key in ("pixel_diff", "hist_diff", "score"):
                if key in row and row[key] != "":
                    row[key] = float(row[key])
            rows.append(row)
    return rows


def write_rows(path, fieldnames, rows):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_scene_list(path):
    scenes = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            scenes.append(int(line.split(",")[0].split()[0]))
    return scenes


def match_scenes(found, reference=REFERENCE_SCENES, tolerance=4):
    matched_ref = set()
    matched_found = set()
    for i, ref in enumerate(reference):
        best_j = None
        best_delta = tolerance + 1
        for j, value in enumerate(found):
            if j in matched_found:
                continue
            delta = abs(value - ref)
            if delta <= tolerance and delta < best_delta:
                best_delta = delta
                best_j = j
        if best_j is not None:
            matched_ref.add(i)
            matched_found.add(best_j)
    return len(matched_ref), len(reference), len(found)
