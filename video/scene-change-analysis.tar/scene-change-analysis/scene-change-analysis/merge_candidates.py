#!/usr/bin/env python3
import argparse

from scene_utils import match_scenes, read_metric_csv


def main():
    parser = argparse.ArgumentParser(description="Merge adjacent scene-change candidates into one boundary per scene.")
    parser.add_argument("--input", default="scene_candidates.txt")
    parser.add_argument("--output", default="scene_frames.txt")
    parser.add_argument("--min-gap", type=int, default=8)
    args = parser.parse_args()

    candidates = read_metric_csv(args.input)
    if not candidates:
        raise SystemExit("No scene candidates found")

    clusters = []
    current = [candidates[0]]
    for row in candidates[1:]:
        if row["frame_index"] - current[-1]["frame_index"] <= args.min_gap:
            current.append(row)
        else:
            clusters.append(current)
            current = [row]
    clusters.append(current)

    scenes = []
    for cluster in clusters:
        weighted = sum(row["frame_index"] * row["score"] for row in cluster)
        total_score = sum(row["score"] for row in cluster)
        center = int(round(weighted / total_score))
        best_score = max(row["score"] for row in cluster)
        scenes.append((center, best_score, len(cluster)))

    with open(args.output, "w", encoding="utf-8") as handle:
        handle.write("# frame_index,score,cluster_size\n")
        for frame_index, score, size in scenes:
            handle.write(f"{frame_index},{score:.6f},{size}\n")

    found = [frame for frame, _, _ in scenes]
    matched, total, found_count = match_scenes(found, tolerance=4)
    if matched < total or found_count != total:
        raise SystemExit(
            f"Merged scenes are not correct: matched={matched}/{total}, scene_count={found_count}. "
            "Review threshold and min-gap."
        )

    print(f"Merged {len(candidates)} candidates into {len(scenes)} scene changes")
    print(f"Scene list saved to {args.output}: {found}")
    print("CHECK5_OK merged_scene_list")


if __name__ == "__main__":
    main()
