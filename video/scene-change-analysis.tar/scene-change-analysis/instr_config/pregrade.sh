#!/bin/bash
homedir=$1
destdir=$2
cd "$homedir/$destdir" || exit 0
exit 0
