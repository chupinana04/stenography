#!/bin/bash
# This script is run after Labtainers parameterization.
exit 0
