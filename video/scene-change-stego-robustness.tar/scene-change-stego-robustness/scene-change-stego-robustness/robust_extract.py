#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path

import cv2

from scene_utils import bits_to_bytes, extract_lsb_bits, keyed_positions, majority_vote_bits, parse_auth_payload
from scene_utils import parse_scene_list, robust_payload_bit_count, save_json


def main():
    parser = argparse.ArgumentParser(description="Recover an attacked payload with repetition and majority voting.")
    parser.add_argument("--frames-dir", default="attacked_frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--key", default="key.txt")
    parser.add_argument("--config", default="robust_config.json")
    parser.add_argument("--payload", default="recovered_payload.bin")
    parser.add_argument("--message", default="recovered_message.txt")
    parser.add_argument("--report", default="robust_report.json")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    frame_files = sorted(Path(args.frames_dir).glob("frame_*.png"))
    if not frame_files:
        raise SystemExit("No attacked frames found")
    sample = cv2.imread(str(frame_files[0]), cv2.IMREAD_COLOR)
    if sample is None:
        raise SystemExit("Could not read sample frame")
    height, width = sample.shape[:2]

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    repetition = int(config["repetition"])
    raw_bit_count = robust_payload_bit_count(config)
    key = Path(args.key).read_text(encoding="utf-8").strip()
    scenes = parse_scene_list(args.scene_list)
    positions = keyed_positions(key, scenes, len(frame_files), width, height, args.radius)
    raw_bits = extract_lsb_bits(args.frames_dir, positions, raw_bit_count)
    voted_bits, corrections = majority_vote_bits(raw_bits, repetition)
    payload = bits_to_bytes(voted_bits)

    try:
        parsed = parse_auth_payload(payload, key)
    except ValueError as error:
        raise SystemExit(f"Majority voting failed to authenticate payload: {error}")

    Path(args.payload).write_bytes(payload)
    Path(args.message).write_bytes(parsed["message"])
    report = {
        "authenticated": True,
        "repetition": repetition,
        "corrected_replicas": corrections,
        "message_bytes": parsed["message_len"],
        "crc32": parsed["crc32"],
        "hmac_prefix": parsed["hmac_prefix"],
        "message_sha256": hashlib.sha256(parsed["message"]).hexdigest(),
    }
    save_json(args.report, report)

    if corrections <= 0:
        raise SystemExit("No replica corrections were detected")
    print(f"Recovered authenticated message after correcting {corrections} damaged replicas")
    print(f"CRC32: {parsed['crc32']}")
    print("CHECK5_OK robust_message_recovered")


if __name__ == "__main__":
    main()
