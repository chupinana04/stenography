#!/usr/bin/env python3
import argparse

from blind_extract import recover_payload
from scene_utils import parse_auth_payload


def main():
    parser = argparse.ArgumentParser(description="Confirm that the wrong key cannot authenticate the hidden message.")
    parser.add_argument("--frames-dir", default="frames")
    parser.add_argument("--scene-list", default="scene_frames.txt")
    parser.add_argument("--wrong-key", default="wrong_key.txt")
    parser.add_argument("--radius", type=int, default=2)
    args = parser.parse_args()

    try:
        payload, _, _, _ = recover_payload(args.frames_dir, args.scene_list, args.wrong_key, args.radius)
        with open(args.wrong_key, encoding="utf-8") as handle:
            wrong_key = handle.read().strip()
        parse_auth_payload(payload, wrong_key)
    except ValueError as error:
        print(f"Wrong key rejected: {error}")
        print("CHECK5_OK wrong_key_rejected")
        return

    raise SystemExit("Wrong key unexpectedly recovered and authenticated a payload")


if __name__ == "__main__":
    main()
